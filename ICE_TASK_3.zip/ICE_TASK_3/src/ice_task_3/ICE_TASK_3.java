/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ice_task_3;

import javax.swing.*;

public class ICE_TASK_3 {

    static String displaySalutation(String surname) {
        String display;
        display = "Mr/Mrs" + surname + " thank you for your order";
        return display;
    }

    static String displaySalutation(String name, String surname) {
        String display;
        display = "Dear " + name + surname + " thank you for your order";
        return display;
    }

    public static void main(String[] args) {

        String surname = JOptionPane.showInputDialog("enter surname");
        String name = JOptionPane.showInputDialog("enter name");
        System.out.println(displaySalutation(surname));
        System.out.println(displaySalutation(name, surname));

    }

}
